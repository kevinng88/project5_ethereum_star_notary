# Project #5. Decentralized Star Notary

This is the project of using Ethereum blockchain for creating star notary service:

1. ERC-721 Token Name: "Kev Token"
2. ERC-721 Token Symbol: "KTN"



## Version of the Truffle and OpenZeppelin used:
1. Truffle v5.0.6
2. Openzeppelin-solidity v2.1.2

    
    